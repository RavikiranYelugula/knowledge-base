# Circuit Breaker using Spring Boot 3 and Resilience4J

![Architecture](./architecture.png)

## Endpoints
- `http://localhost:8080/activity` returns random activity from `boredapi.com`
