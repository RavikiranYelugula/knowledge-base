package com.techprimers.circuitbreaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitbreakerResilience4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
