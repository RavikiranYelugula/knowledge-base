package com.programming.techie.loans.entity;

public enum Currency {
    INR, USD, EUR
}
