package com.programming.techie.loans.entity;

public enum LoanStatus {
    APPROVED, REJECTED
}
