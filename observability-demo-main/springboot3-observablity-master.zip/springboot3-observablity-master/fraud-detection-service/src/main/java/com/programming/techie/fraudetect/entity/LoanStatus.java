package com.programming.techie.fraudetect.entity;

public enum LoanStatus {
    APPROVED, REJECTED
}
