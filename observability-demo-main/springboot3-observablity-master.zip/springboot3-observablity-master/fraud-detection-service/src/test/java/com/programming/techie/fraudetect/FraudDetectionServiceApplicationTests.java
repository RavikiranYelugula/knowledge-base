package com.programming.techie.fraudetect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudDetectionServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
