create schema loan_service;
create schema fraud_detection;
