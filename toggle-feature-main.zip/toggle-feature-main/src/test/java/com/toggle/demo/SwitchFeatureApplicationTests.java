package com.toggle.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwitchFeatureApplicationTests {

	@Test
	void contextLoads() {
	}

}
